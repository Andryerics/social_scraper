from .user import User
from .comments import Comments
# tikapi/__init__.py
from .instagram import InstagramScraper
from .post import Post
