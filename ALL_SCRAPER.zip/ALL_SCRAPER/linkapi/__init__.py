# linkapi/__init__.py
from .user import UserProfile
from .company import CompanyScraper
from .jobs import JobsInfos
from .all_jobs import AllJobs
from .search import Search

# Optionnellement, vous pouvez également rendre disponibles les autres fonctions si nécessaire.
#__all__ = ["CompanyScraper"]
