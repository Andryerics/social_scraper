import asyncio
import json
import random
import time
from flask import Flask, jsonify, request
import asyncio
import json
from tikapi import User, Post, Comments, InstagramScraper
from linkapi import UserProfile, CompanyScraper, JobsInfos, Search, AllJobs
from all_scraper import Scraper
from loguru import logger as log

app = Flask(__name__)
scraper = Scraper() # Usage for all_scraper


# Helper function to run async functions in Flask
def run_async(func):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    return loop.run_until_complete(func)

################
##### TIKAPI #####

# Route /user pour scraper les profils TikTok
@app.route('/tiktok/user', methods=['POST'])
def tikapi_scrape_user():
    urls = request.form.getlist("urls")  # Récupérer les URLs comme liste depuis le formulaire

    async def scrape_profiles(urls):
        user = User()
        result = await user.scrape_profiles(urls=urls)
        return result

    result = asyncio.run(scrape_profiles(urls))
    return jsonify(result)

# Route /post pour scraper les posts TikTok
@app.route('/tiktok/post', methods=['POST'])
def tikapi_scrape_post():
    urls = request.form.getlist("urls")  # Récupérer les URLs comme liste depuis le formulaire

    async def scrape_posts(urls):
        post = Post()
        result = await post.scrape_posts(urls=urls)
        return result

    result = asyncio.run(scrape_posts(urls))
    return jsonify(result)

# Route /comments pour scraper les commentaires TikTok
@app.route('/tiktok/comments', methods=['POST'])
def tikapi_scrape_comments():
    post_id = request.form.get("post_id")  # Récupérer l'ID du post depuis le formulaire
    max_comments = int(request.form.get("max_comments", 100))  # Valeur par défaut : 100
    comments_count = int(request.form.get("comments_count", 20))  # Valeur par défaut : 20

    async def scrape_comments(post_id, max_comments, comments_count):
        comments_scraper = Comments()
        result = await comments_scraper.scrape_comments(
            post_id=post_id,
            max_comments=max_comments,
            comments_count=comments_count
        )
        return result

    result = asyncio.run(scrape_comments(post_id, max_comments, comments_count))
    return jsonify(result)

# Route /insta pour scraper les données d'utilisateur Instagram
@app.route('/tiktok/insta', methods=['POST'])
def tikapi_scrape_insta():
    username = request.form.get("username")  # Récupérer le nom d'utilisateur depuis le formulaire

    def scrape_instagram_user(username):
        scraper = InstagramScraper()
        result = scraper.scrape_user(username)
        return result

    result = scrape_instagram_user(username)
    return jsonify(result)


#####################
##### ALL_SCRAPER #####

# Exemple de route pour récupérer les commentaires d'un post TikTok
@app.route("/scrapi/tiktok/comment", methods=['POST'])
def scrapi_fetch_tiktok_comment():
    aweme_id = request.form.get('aweme_id')
    if aweme_id:
        result = scraper.fetch_post_comment(aweme_id)
        return jsonify(result)
    return jsonify({"error": "aweme_id missing"}), 400

# Exemple de route pour récupérer le profil utilisateur TikTok
@app.route("/scrapi/tiktok/user", methods=['POST'])
def scrapi_fetch_tiktok_user_profile():
    unique_id = request.form.get('unique_id')
    if unique_id:
        result = scraper.fetch_user_profile(unique_id)
        return jsonify(result)
    return jsonify({"error": "unique_id missing"}), 400

# Exemple de route pour récupérer les réponses à un commentaire TikTok
@app.route("/scrapi/tiktok/comment_reply", methods=['POST'])
def scrapi_fetch_tiktok_comment_reply():
    item_id = request.form.get('item_id')
    comment_id = request.form.get('comment_id')
    if item_id and comment_id:
        result = scraper.fetch_post_comment_reply(item_id, comment_id)
        return jsonify(result)
    return jsonify({"error": "item_id or comment_id missing"}), 400

# Exemple de route pour obtenir le sec_user_id à partir d'une URL encodée TikTok
@app.route("/scrapi/tiktok/sec_user_id", methods=['POST'])
def scrapi_get_tiktok_sec_user_id():
    url_encoded = request.form.get('url_encoded')
    if url_encoded:
        result = scraper.get_sec_user_id(url_encoded)
        return jsonify(result)
    return jsonify({"error": "url_encoded missing"}), 400

# Exemple de route pour télécharger une vidéo TikTok
@app.route("/scrapi/tiktok/download_video", methods=['POST'])
def scrapi_download_tiktok_video():
    tiktok_url = request.form.get('tiktok_url')
    if tiktok_url:
        result = scraper.download_tiktok_video(tiktok_url)
        return jsonify(result)
    return jsonify({"error": "tiktok_url missing"}), 400

# Exemple de route pour stalker un profil Instagram
@app.route("/scrapi/instagram/profile", methods=['POST'])
def scrapi_stalk_instagram_profile():
    instagram_username = request.form.get('instagram_username')
    if instagram_username:
        result = scraper.stalk_instagram_profile(instagram_username)
        return jsonify(result)
    return jsonify({"error": "instagram_username missing"}), 400

# Exemple de route pour récupérer les commentaires d'une vidéo Bilibili
@app.route("/scrapi/bilibili/comments", methods=['POST'])
def scrapi_fetch_bilibili_video_comments():
    bv_id = request.form.get('bv_id')
    if bv_id:
        result = scraper.fetch_bilibili_video_comments(bv_id)
        return jsonify(result)
    return jsonify({"error": "bv_id missing"}), 400

# Exemple de route pour récupérer les réponses à un commentaire Bilibili
@app.route("/scrapi/bilibili/comment_reply", methods=['POST'])
def scrapi_fetch_bilibili_comment_reply():
    bv_id = request.form.get('bv_id')
    rpid = request.form.get('rpid')
    if bv_id and rpid:
        result = scraper.fetch_bilibili_comment_reply(bv_id, rpid=rpid)
        return jsonify(result)
    return jsonify({"error": "bv_id or rpid missing"}), 400

# Exemple de route pour télécharger une vidéo Xvideos
@app.route("/scrapi/xvideos/download", methods=['POST'])
def scrapi_download_xvideos_video():
    xvideos_url = request.form.get('xvideos_url')
    if xvideos_url:
        result = scraper.download_xvideos_video(xvideos_url)
        return jsonify(result)
    return jsonify({"error": "xvideos_url missing"}), 400

# Exemple de route pour chercher des vidéos sur Xvideos
@app.route("/scrapi/xvideos/search", methods=['POST'])
def scrapi_search_xvideos():
    xvideos_query = request.form.get('xvideos_query')
    if xvideos_query:
        result = scraper.search_xvideos(xvideos_query)
        return jsonify(result)
    return jsonify({"error": "xvideos_query missing"}), 400

# Exemple de route pour récupérer un profil utilisateur Douyin
@app.route("/scrapi/douyin/user", methods=['POST'])
def scrapi_fetch_douyin_user_profile():
    sec_user_id = request.form.get('sec_user_id')
    if sec_user_id:
        result = scraper.fetch_user_profile_douyin(sec_user_id)
        return jsonify(result)
    return jsonify({"error": "sec_user_id missing"}), 400

# Exemple de route pour récupérer les vidéos d'un utilisateur Douyin
@app.route("/scrapi/douyin/user_videos", methods=['POST'])
def scrapi_fetch_douyin_user_videos():
    sec_user_id = request.form.get('sec_user_id')
    if sec_user_id:
        result = scraper.fetch_user_post_videos(sec_user_id)
        return jsonify(result)
    return jsonify({"error": "sec_user_id missing"}), 400

# Exemple de route pour récupérer les commentaires d'une vidéo Douyin
@app.route("/scrapi/douyin/video_comments", methods=['POST'])
def scrapi_fetch_douyin_video_comments():
    aweme_id = request.form.get('aweme_id')
    if aweme_id:
        result = scraper.fetch_video_comments(aweme_id)
        return jsonify(result)
    return jsonify({"error": "aweme_id missing"}), 400



################
##### TIKAPI #####

@app.route('/linkedin/user', methods=['POST'])
def linkapi_user_profile():
    """Endpoint to scrape user profile."""
    url = request.form.get('url')
    if not url:
        return "URL is required", 400

    async def scrape_user_profile():
        user_profile = UserProfile(url)
        html_content = await user_profile.fetch_html()
        if not html_content:
            return {"error": "Failed to retrieve HTML content"}, 500

        profile_data = user_profile.parse_profile(html_content)
        return profile_data

    data = run_async(scrape_user_profile())
    return jsonify(data)

@app.route('/linkedin/company', methods=['POST'])
def linkapi_company_info():
    """Endpoint to scrape company information."""
    url = request.form.get('url')
    if not url:
        return "URL is required", 400

    async def scrape_company_info():
        scraper = CompanyScraper(url)
        extracted_info = await scraper.fetch_and_save_html()
        return extracted_info if extracted_info else {}

    data = run_async(scrape_company_info())
    return jsonify(data)

@app.route('/linkedin/jobs', methods=['POST'])
def linkapi_jobs_info():
    """Endpoint to scrape jobs information."""
    url = request.form.get('url')
    max_pages = int(request.form.get('max_pages', 1))

    async def scrape_jobs_info():
        scraper = JobsInfos(url=url, max_pages=max_pages)
        json_output = await scraper.get_json()  # Renvoie maintenant un objet Python
        return json_output

    data = run_async(scrape_jobs_info())
    return jsonify(data)  # jsonify traite l'objet Python directement

@app.route('/linkedin/search', methods=['POST'])
def linkapi_job_search():
    """Endpoint to perform a job search."""
    keyword = request.form.get('keyword')
    location = request.form.get('location')
    max_pages = int(request.form.get('max_pages', 1))

    async def scrape_job_search():
        search = Search()
        job_search_data = await search.scrape_job_search(
            keyword=keyword,
            location=location,
            max_pages=max_pages
        )
        return job_search_data

    data = run_async(scrape_job_search())
    return jsonify(data)

@app.route('/linkedin/all_jobs', methods=['POST'])
def linkapi_all_jobs():
    """Endpoint to scrape detailed job information."""
    urls = request.form.getlist('urls')

    async def scrape_all_jobs():
        job_data = await AllJobs.run(urls)
        return job_data

    data = run_async(scrape_all_jobs())
    return jsonify(data)



if __name__ == "__main__":
    #app.run(host="0.0.0.0", port=8900)
    app.run()
    